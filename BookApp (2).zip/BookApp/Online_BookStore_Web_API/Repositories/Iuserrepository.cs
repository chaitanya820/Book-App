﻿using Online_BookStore_Web_API.Entities;

namespace Online_BookStore_Web_API.Repositories
{
    public interface IUserRepository
    {
        void Register(User user);
        User ValidUser(string email, string password);
        List<User> GetAllUsers();
        void Edit(User user);
        void Delete(String UserId);

    }

}


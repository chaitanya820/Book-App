﻿using Online_BookStore_Web_API.Entities;
using Microsoft.EntityFrameworkCore;
using static Online_BookStore_Web_API.Repositories.IorderItemRepository;
namespace Online_BookStore_Web_API.Repositories
{
    public class OrderItemRepository : IOrderItemRepository
    {
        private readonly Online_BookStoreContext _context;

        public OrderItemRepository(Online_BookStoreContext context)
        {
            _context = context;
        }

        public async Task AddAsync(OrderItem orderItem)
        {
            _context.OrderItems.Add(orderItem);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteByIdAsync(string id)
        {
            var orderItem = await _context.OrderItems.FindAsync(id);
            if (orderItem != null)
            {
                _context.OrderItems.Remove(orderItem);
                await _context.SaveChangesAsync();
            }
        }

        public async Task UpdateAsync(OrderItem orderItem)
        {
            _context.Entry(orderItem).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task<List<OrderItem>> GetAllAsync()
        {
            return await _context.OrderItems.ToListAsync();
        }

        public async Task<OrderItem> GetByIdAsync(string id)
        {
            return await _context.OrderItems.FindAsync(id);
        }
    }
}

    

    


﻿using Online_BookStore_Web_API.Entities;

namespace Online_BookStore_Web_API.Repositories
{  
    public interface IPaymentRepository
    {
        void AddPayment(Payment payment);
        List<Payment> GetAllPayments();
        Payment GetPaymentById(Guid id);
        void UpdatePayment(Payment payment);
        void DeletePayment(Guid id);
    }
}
    
    


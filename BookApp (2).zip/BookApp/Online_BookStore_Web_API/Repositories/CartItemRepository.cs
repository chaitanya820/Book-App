﻿using Online_BookStore_Web_API.Entities;
using static Online_BookStore_Web_API.Repositories.CartItemRepository;

namespace Online_BookStore_Web_API.Repositories
{
    public class CartItemRepository : ICartItemRepository
    {
        private readonly Online_BookStoreContext _context;
        private IConfiguration _configuration;

        public CartItemRepository(Online_BookStoreContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public void AddCartItem(CartItem cartitem)
        {
            _context.CartItems.Add(cartitem);
            _context.SaveChanges();
        }

        public void DeleteCartItem(Guid id)
        {
            var item = _context.CartItems.Find(id);
            _context.CartItems.Remove(item);
            _context.SaveChanges();
        }

        public List<CartItem> GetAllCartItems()
        {
            return _context.CartItems.ToList();
        }

        public CartItem GetCartItemById(Guid id)
        {
            var item = _context.CartItems.Find(id);
            return item;
        }

        public void UpdateCartItem(CartItem cartitem)
        {
            _context.CartItems.Update(cartitem);
            _context.SaveChanges();
        }
    }
}



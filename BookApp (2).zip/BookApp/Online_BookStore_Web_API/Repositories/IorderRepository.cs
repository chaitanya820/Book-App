﻿using Online_BookStore_Web_API.Entities;

namespace Online_BookStore_Web_API.Repositories
{
    public interface IOrderRepository
    {
        void Add(Order order);
        Order GetOrder(Guid orderId);
        List<Order> GetAllOrders();
        void Delete(Guid id);
    }
}

        

 

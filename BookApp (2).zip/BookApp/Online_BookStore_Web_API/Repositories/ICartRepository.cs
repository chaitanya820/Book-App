﻿using Online_BookStore_Web_API.Entities;

namespace Online_BookStore_Web_API.Repositories
{
    public interface ICartItemRepository
    {
        List<CartItem> GetAllCartItems();
        CartItem GetCartItemById(Guid id);
        void DeleteCartItem(Guid id);
        void UpdateCartItem(CartItem cartitem);
        void AddCartItem(CartItem cartitem);
    }
}

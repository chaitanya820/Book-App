﻿using Online_BookStore_Web_API.Entities;

namespace Online_BookStore_Web_API.Repositories
{
    public class OrderRepository :IOrderRepository
    {
        private readonly Online_BookStoreContext _context;
        private ICategoryRepository _categoryRepository;

        public OrderRepository(Online_BookStoreContext context, ICategoryRepository categoryRepository)
        {
            _context = context;
            _categoryRepository = categoryRepository;
        }

        public void Add(Order order)
        {
            _context.Orders.Add(order);
            _context.SaveChanges();
        }

        public void Delete(Guid orderid)
        {
            var order = _context.Orders.Find(orderid);
            _context.Orders.Remove(order);
            _context.SaveChanges();
        }

        public List<Order> GetAllOrders()
        {
            return _context.Orders.ToList();
        }

        public Order GetOrder(Guid orderId)
        {
            var orders = _context.Orders.Find(orderId);
            return orders;
        }
    }

}


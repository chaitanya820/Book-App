﻿using Online_BookStore_Web_API.Entities;

namespace Online_BookStore_Web_API.Repositories
{
    public interface IWishListRepository
    {
        void Add(Wishlist wishlist);
        Wishlist GetFavoriteById(string favoriteId);
        List<Wishlist> GetAllFavorites();
        void Delete(string id);
        void Update(Wishlist wishlist);
    }
}

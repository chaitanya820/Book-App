﻿using Online_BookStore_Web_API.Entities;

namespace Online_BookStore_Web_API.Repositories
{
    public class IorderItemRepository
    {
        public interface IOrderItemRepository
        {
            Task AddAsync(OrderItem orderItem);
            Task DeleteByIdAsync(string id);
            Task UpdateAsync(OrderItem orderItem);
            Task<List<OrderItem>> GetAllAsync();
            Task<OrderItem> GetByIdAsync(string id);
        }
    }
}


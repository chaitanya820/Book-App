﻿using Online_BookStore_Web_API.Entities;

namespace Online_BookStore_Web_API.Repositories
{
    public class WishListRepository : IWishListRepository
    {
        private readonly Online_BookStoreContext _context;
        private IConfiguration _configuration;
        public void Add(Wishlist wishlist)
        {
            _context.Wishlists.Add(wishlist);
            _context.SaveChanges();
        }

        public void Delete(string id)
        {
            var favorite = _context.Wishlists.Find(id);
            _context.Wishlists.Remove(favorite);
            _context.SaveChanges();
        }

        public List<Wishlist> GetAllFavorites()
        {
            return _context.Wishlists.ToList();
        }

        public Wishlist GetFavoriteById(string favoriteId)
        {
            var favorite = _context.Wishlists.Find(favoriteId);
            return favorite;
        }

        public void Update(Wishlist wishlist)
        {
            _context.Wishlists.Update(wishlist);
            _context.SaveChanges();
        }
    }
}

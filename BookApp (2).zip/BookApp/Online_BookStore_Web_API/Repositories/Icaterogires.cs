﻿using Online_BookStore_Web_API.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Online_BookStore_Web_API.Repositories
{
    public interface ICategoryRepository
    {
        Task<IEnumerable<Category>> GetAllCategoriesAsync();
        Task<Category> GetCategoryByIdAsync(string categoryId);
        Task AddCategoryAsync(Category category);
        Task UpdateCategoryAsync(Category category);
        Task DeleteCategoryAsync(string categoryId);
    }
}


  


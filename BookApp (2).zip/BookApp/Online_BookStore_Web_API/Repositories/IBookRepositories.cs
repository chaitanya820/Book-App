﻿using Online_BookStore_Web_API.Entities;
namespace Online_BookStore_Web_API.Repositories
{
    public interface IBookRepository
    {
        Task<List<Book>> GetAllBooks();
        Task<Book> GetBookById(int id);
        Task<Book> AddBook(Book book);
        Task<Book> UpdateBook(Book book);
        Task Delete(int id);
    }


}


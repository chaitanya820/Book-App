﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Online_BookStore_Web_API.Entities;
using Online_BookStore_Web_API.Repositories;
using static Online_BookStore_Web_API.Repositories.IorderItemRepository;

namespace Online_BookStore_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemController : ControllerBase
    {
        private readonly IOrderItemRepository _repository;
        private readonly IConfiguration _configuration;

        public OrderItemController(IOrderItemRepository repository, IConfiguration configuration)
        {
            _repository = repository;
            _configuration = configuration;
        }

        [HttpGet("GetAll")]
        public async Task<ActionResult<IEnumerable<OrderItem>>> GetAll()
        {
            var orderItems = await _repository.GetAllAsync();
            return Ok(orderItems);
        }

        [HttpGet("GetById/{id}")]
        public async Task<ActionResult<OrderItem>> Get(string id)
        {
            var orderItem = await _repository.GetByIdAsync(id);
            if (orderItem == null)
            {
                return NotFound();
            }
            return Ok(orderItem);
        }

        [HttpPost("AddOrderItem")]
        public async Task<ActionResult<OrderItem>> Add([FromBody] OrderItem orderItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _repository.AddAsync(orderItem);
                return Ok(orderItem);
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "An error occurred while adding the order item.");
            }
        }

        [HttpPut("Edit")]
        public async Task<ActionResult<OrderItem>> Edit([FromBody] OrderItem orderItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _repository.UpdateAsync(orderItem);
                return Ok(orderItem);
            }
            catch (DbUpdateConcurrencyException)
            {
                return StatusCode(500, "An error occurred while deleting the order item.");
            }
        }

        [HttpDelete("DeleteOrderItem/{id}")]
        public async Task<ActionResult> Delete(string id)
        {
            var orderItem = await _repository.GetByIdAsync(id);
            if (orderItem == null)
            {
                return NotFound();
            }

            try
            {
                await _repository.DeleteByIdAsync(id);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "An error occurred while deleting the order item.");
            }
        }
    }
}
﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_BookStore_Web_API.Entities;
using Online_BookStore_Web_API.Repositories;

namespace Online_BookStore_Web_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepository bookRepository;

        public BooksController(IBookRepository bookRepository)
        {
            this.bookRepository = bookRepository;
        }

        // GET: api/books
        [HttpGet]
        [Route("GetBooks")]
        public async Task<IActionResult> GetAllBooks()
        {
            var books = await bookRepository.GetAllBooks();
            if (!books.Any())
            {
                return NotFound();
            }
            return Ok(books);
        }

        // GET: api/books/{id}
        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetBookById(int id)
        {
            var book = await bookRepository.GetBookById(id);
            if (book == null)
            {
                return NotFound();
            }
            return Ok(book);
        }

        // POST: api/books
        [HttpPost]
        [Route("AddBook")]
        public async Task<IActionResult> AddBook([FromBody] Book book)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await bookRepository.AddBook(book);
            return Ok(book);
        }

        // PUT: api/books/{id}
        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdateBook(int id, [FromBody] Book book)
        {
            if (!ModelState.IsValid || id != book.Id)
            {
                return BadRequest(ModelState);
            }

            await bookRepository.UpdateBook(book);
            return NoContent(); // Consider returning the updated entity if needed
        }

        // DELETE: api/books/{id}
        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            await bookRepository.Delete(id);
            return NoContent(); // Indicates successful deletion
        }
    }
}

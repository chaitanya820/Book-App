﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_BookStore_Web_API.Entities;
using Online_BookStore_Web_API.Repositories;

namespace Online_BookStore_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {


        private readonly IOrderRepository _orderRepository;
        private readonly IConfiguration _configuration;

        public OrderController(IOrderRepository orderRepository, IConfiguration configuration)
        {
            _orderRepository = orderRepository;
            _configuration = configuration;
        }
        [HttpGet, Route("GetOrders")]
        public IActionResult GetAlOrdersl()
        {
            var orders = _orderRepository.GetAllOrders();
            return StatusCode(200, orders);
        }
        [HttpGet, Route("GetById/{id}")]
        public IActionResult GetOrders([FromRoute] Guid id)
        {
            var order = _orderRepository.GetOrder(id);
            if (order != null)
            {
                return StatusCode(200, order);
            }
            else
            {
                return StatusCode(404, "Invalid Code");
            }
        }

        [HttpPost, Route("AddOrder")]
        public IActionResult Add([FromBody] Order order)
        {
            order.OrderId = Guid.NewGuid();
            _orderRepository.Add(order);

            return StatusCode(200, order);

        }
        [HttpDelete, Route("DeleteOrder")]
        public IActionResult Delete([FromQuery] Guid id)
        {
            _orderRepository.Delete(id);
            return Ok();
        }
    }
        
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_BookStore_Web_API.Entities;
using Online_BookStore_Web_API.Repositories;

namespace Online_BookStore_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        
        private readonly IPaymentRepository _paymentRepository;
        private readonly IConfiguration _configuration;

        public PaymentController(IPaymentRepository paymentRepository, IConfiguration configuration)
        {
            _paymentRepository = paymentRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetAllTransactions")]
        public IActionResult GetAllPayments()
        {
            var payment = _paymentRepository.GetAllPayments();
            return StatusCode(200, payment);
        }
        [HttpGet, Route("GetById/{id}")]
        public IActionResult GetPayments([FromRoute] Guid id)
        {
            var payment = _paymentRepository.GetPaymentById(id);
            if (payment != null)
            {
                return StatusCode(200, payment);
            }
            else
            {
                return StatusCode(404, "Invalid Code");
            }
        }

        [HttpPost, Route("AddPayment")]
        public IActionResult Add([FromBody] Payment payment)
        {
            payment.PaymentId = Guid.NewGuid();
            _paymentRepository.AddPayment(payment);
            return StatusCode(200, payment);
        }
        [HttpDelete, Route("DeleteOrder")]
        public IActionResult Delete([FromQuery] Guid id)
        {
            _paymentRepository.DeletePayment(id);
            return Ok();

        }


    }
}
    


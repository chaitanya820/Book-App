﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_BookStore_Web_API.Entities;
using Online_BookStore_Web_API.Repositories;

namespace Online_BookStore_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartItemController : ControllerBase
    {
         
        private readonly ICartItemRepository _cartItemRepository;
        private IConfiguration _configuration;

        public CartItemController(ICartItemRepository cartItemRepository, IConfiguration configuration)
        {
            _cartItemRepository = cartItemRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetCartItems")]
        public IActionResult GetAll()
        {
            var items = _cartItemRepository.GetAllCartItems();
            return StatusCode(200, items);
        }
        [HttpGet, Route("GetItems/{id}")]
        public IActionResult Get([FromRoute] Guid id)
        {
            var favorite = _cartItemRepository.GetCartItemById(id);
            if (favorite != null)
            {
                return StatusCode(200, favorite);
            }
            else
                return StatusCode(404, "Invalid Id");
        }
        [HttpPost, Route("AddCartItem")]
        public IActionResult Add([FromBody] CartItem cartItem)
        {
            _cartItemRepository.AddCartItem(cartItem);
            return StatusCode(200, cartItem);
        }
        [HttpPut, Route("EditCartItem")]
        public IActionResult Edit([FromBody] CartItem cartItem)
        {
            _cartItemRepository.UpdateCartItem(cartItem);
            return StatusCode(200, cartItem);
        }
        [HttpDelete, Route("DeleteCartItem")]
        public IActionResult Delete([FromQuery] Guid id)
        {
            _cartItemRepository.DeleteCartItem(id);
            return Ok();
        }
    }
}
    


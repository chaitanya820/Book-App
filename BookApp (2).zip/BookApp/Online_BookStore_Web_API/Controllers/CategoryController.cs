﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_BookStore_Web_API.Entities;
using Online_BookStore_Web_API.Repositories;


namespace Online_BookStore_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryRepository _repository;

        public CategoryController(ICategoryRepository repository)
        {
            _repository = repository;
        }

        // GET: api/Category/GetAll
        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var categories = await _repository.GetAllCategoriesAsync();
            return Ok(categories);
        }

        // GET: api/Category/GetById/{id}
        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            var category = await _repository.GetCategoryByIdAsync(id);
            if (category == null)
            {
                return NotFound();
            }
            return Ok(category);
        }

        // POST: api/Category/AddCategory
        [HttpPost, Route("AddCategory")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Add([FromBody] Category category)
        {
            if (category == null)
            {
                return BadRequest("Category cannot be null.");
            }

            if (string.IsNullOrEmpty(category.Name))
            {
                return BadRequest("Category name is required.");
            }

            await _repository.AddCategoryAsync(category);

            return CreatedAtAction(nameof(Get), new { id = category.CategoryId }, category);
        }

        // PUT: api/Category/Edit
        [HttpPut, Route("Edit")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Edit([FromBody] Category category)
        {
            var existingCategory = await _repository.GetCategoryByIdAsync(category.CategoryId);
            if (existingCategory == null)
            {
                return NotFound();
            }

            await _repository.UpdateCategoryAsync(category);
            return NoContent();
        }

        // DELETE: api/Category/Delete/{id}
        [HttpDelete, Route("Delete/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Delete([FromRoute] string id)
        {
            var category = await _repository.GetCategoryByIdAsync(id);
            if (category == null)
            {
                return NotFound();
            }
            await _repository.DeleteCategoryAsync(id);
            return NoContent();
        }
    }
 }


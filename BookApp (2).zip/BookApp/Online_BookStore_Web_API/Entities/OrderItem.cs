﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Online_BookStore_Web_API.Entities
{
    public class OrderItem
    {
        [Key]
        public Guid OrderItemId { get; set; }
        [ForeignKey("Order")]
        public Guid OrderId { get; set; }

        [ForeignKey("Book")]
        public int BookId { get; set; }
        [Required(ErrorMessage = "Price is Required")]
        public decimal Price { get; set; }
        [Required(ErrorMessage = "Quantity is Required")]
        public int Quantity { get; set; }
        [ForeignKey("CartItem")]

        public int CartItemId { get; set; }
        public decimal TotalPrice => Quantity * Price;

        [JsonIgnore]
        public Book? Book { get; set; }
        [JsonIgnore]
        public virtual Order? Order { get; set; }

    }
}

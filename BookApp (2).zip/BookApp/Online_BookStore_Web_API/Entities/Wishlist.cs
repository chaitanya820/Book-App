﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Online_BookStore_Web_API.Entities
{
    public class Wishlist
    {
            [Key]
            [Required(ErrorMessage = "FavoriteId is Required")]

            [Column(TypeName = "varchar")]
            [StringLength(10)]
            public string FavoriteId { get; set; }

            [ForeignKey("User")]
            public int UserId { get; set; }

            [ForeignKey("Book")]
            public int BookId { get; set; }

            [JsonIgnore]
            public User? User { get; set; }
            [JsonIgnore]
            public Book? book { get; set; }
    }
    
}


﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Online_BookStore_Web_API.Entities
{
    public class Order
    {
        [Key]

        public Guid OrderId { get; set; }

        [ForeignKey("User")]
        public int UserId { get; set; } // Set as ForeignKey
        [ForeignKey("Book")]
        public int BookId { get; set; }
        [Column(TypeName = "varchar")]
        [StringLength(100)]
        public string Address { get; set; }

        [Column(TypeName = "varchar")]
        [StringLength(100)]
        public string OrderStatus { get; set; }
        [Column(TypeName = "Date")]
        [Required(ErrorMessage = "OrderDate is Required")]
        public DateTime OrderDate { get; set; }

        public int Quantity { get; set; }
        [Column(TypeName = "Date")]
        [Required(ErrorMessage = "DeliveryDate is Required")]

        public DateTime DeliveryDate { get; set; }
        [JsonIgnore]
        public User? User { get; set; }
        [JsonIgnore]
        public Book? Book { get; set; }

    }
}

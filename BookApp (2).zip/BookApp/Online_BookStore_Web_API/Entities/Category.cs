﻿using System.ComponentModel.DataAnnotations;

namespace Online_BookStore_Web_API.Entities
{
    public class Category
    {
      [Key]
      public string CategoryId { get; set; }
      [Required] // Set Name as not null
      [StringLength(50)]
       public string Name { get; set; }

     }


}


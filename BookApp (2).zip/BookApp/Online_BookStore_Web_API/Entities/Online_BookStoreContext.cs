﻿using Microsoft.EntityFrameworkCore;

namespace Online_BookStore_Web_API.Entities
{
    public class Online_BookStoreContext : DbContext
    {

        private IConfiguration _configuration;

        public Online_BookStoreContext (IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Wishlist> Wishlists { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
                var connectionString = _configuration.GetConnectionString("BookStoreConnection");
                optionsBuilder.UseSqlServer(connectionString);
            
        }
    }
}


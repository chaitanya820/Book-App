﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Online_BookStore_Web_API.Entities
{
    public class Book
    {
        [Key]
     public int Id { get; set; }
     public string Title { get; set; }
     public string Author { get; set; }
     public int Price { get; set; }
    }
}





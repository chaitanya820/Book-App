﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Online_BookStore_Web_API.Entities
{
    public class CartItem
    {

        [Key]
        [Required(ErrorMessage = "cartitemId is required")]
        public Guid CartItemId { get; set; }


        [ForeignKey("Id")]

        public int BookId { get; set; }
        [Required(ErrorMessage = "Price is Required")]

        public int Price { get; set; }

        [Required(ErrorMessage = "Quantity is Required")]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "Price is Required")]
        public int TotalPrice { get; set; }


        [JsonIgnore]
        public Book? Book { get; set; }
        


    }
}



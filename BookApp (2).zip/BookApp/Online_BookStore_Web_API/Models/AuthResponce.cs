﻿namespace Online_BookStore_Web_API.Models
{
    public class AuthResponse
    {
        public int UserId { get; set; }
        public string Role { get; set; }
        public string Address { get; set; }
        public string Token { get; set; }
        
    }



}

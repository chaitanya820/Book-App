import axios from "axios";
import { useEffect, useState } from "react";

const ViewCart = () => {
  const [cartItems, setCartItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);

  useEffect(() => {
    let userId = sessionStorage.getItem("userId");

    axios
      .get(`http://localhost:5139/api/CartItem/GetCartItems?userId=${userId}`)
      .then((response) => {
        console.log(response.data);
        setCartItems(response.data);
        calculateTotalPrice(response.data); // Pass cartItems to calculate the total price after fetching
      })
      .catch((error) => console.error("Error fetching cart items:", error));
  }, []);

  const calculateTotalPrice = (cartItems) => {
    let tot = cartItems.reduce(
      (total, item) => total + item.price * item.quantity,
      0
    );
    setTotalPrice(tot);
  };

  const removeCartItem = (cartItemId) => {
    console.log(`Removing cart item ${cartItemId}`);
  };

  const makeOrder = () => {
    const order = {
      userId: sessionStorage.getItem("userId"),
      bookId: 1,
      address: sessionStorage.getItem("address"),
      orderStatus:"Success",
      orderDate: new Date(),
      quantity:1,
      totalPrice: totalPrice,
    };

    console.log(order);

    axios
      .post("http://localhost:5139/api/Order/AddOrder", order)
      .then((response) => {
        console.log(response.data);
        cartItems.forEach((item) =>
          addItemToOrder(item.cartItemId, response.data.orderId)
        );
      })
      .catch((error) => console.error("Error adding order:", error));
  };

  const addItemToOrder = (cartItemId, orderId) => {
    // Implement logic to add item to order
    console.log(`Adding item ${cartItemId} to order`);
  };

  return (
    <>
      <table className="table table-hover">
        <thead>
          <tr>
            <th>Book ID</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total Price</th>
            <th>Action</th> {/* Make sure Action column is defined */}
          </tr>
        </thead>
        <tbody>
          {cartItems.map((item) => (
            <tr key={item.cartItemId}>
              <td>{item.bookId}</td>
              <td>{item.price}</td>
              <td>{item.quantity}</td>
              <td>{(item.price * item.quantity).toFixed(2)}</td>
              <td>
                <button onClick={() => removeCartItem(item.cartItemId)}>
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div>Total Price: ${totalPrice.toFixed(2)}</div>
      <button onClick={makeOrder}>Make Order</button>
    </>
  );
};

export default ViewCart;

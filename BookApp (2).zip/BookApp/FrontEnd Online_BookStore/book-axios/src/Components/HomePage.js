import React, { useEffect, useState } from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import axios from 'axios';

const HomePage = () => {
  const [books, setBooks] = useState([]);

  // Fetch books from the API
  useEffect(() => {
    axios
      .get('http://localhost:5139/api/Books/GetBooks')
      .then((response) => {
        setBooks(response.data); // Assuming response.data contains the array of books
      })
      .catch((error) => {
        console.error('There was an error fetching the books!', error);
      });
  }, []);

  return (
    <div className="App">
      <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Brand href="#home">Bookstore</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="#dashboard">Dashboard</Nav.Link>
              <Nav.Link href="#login">Login</Nav.Link>
              <Nav.Link href="#logout">Logout</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Main content area */}
      <div className="container mt-5 pt-3">
        <h1>Welcome to Bookstore</h1>
        <p>Discover your next favorite book!</p>
         {/* Grid layout for books */}
        <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
          {books.length > 0 ? (
            books.map((book) => (
              <div key={book.id} className="col">
                <div className="card h-100">
                  <img
                    src={book.coverImageUrl || 'https://via.placeholder.com/50x75'}
                    alt="Book Cover"
                    className="card-img-top"
                    style={{ objectFit: 'cover' }}
                  />
                  <div className="card-body d-flex flex-column justify-content-between">
                    <h5 className="card-title mb-3">{book.title}</h5>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p>Loading books...</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default HomePage;

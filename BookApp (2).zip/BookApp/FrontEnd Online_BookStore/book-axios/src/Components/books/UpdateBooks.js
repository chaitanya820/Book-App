import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

const UpdateBook = () => {
  const { id } = useParams(); // Obtain book ID from URL parameters
  const [book, setBook] = useState({
    Id: "",
    title: "",
    author: "",
    price: 0,
  });

  // Fetch book details by ID

const getBookById = async () => {
  try {
    const response = await axios.get(`http://localhost:5139/api/books/${id}`, {
      params: { id }
    });
    console.log("Fetched book data:", response.data); // Debug: log fetched data
    setBook(response.data);
  } catch (error) {
    console.error("Error fetching book details:", error);
    alert("Error fetching book details: " + (error.response?.data || error.message));
  }
};


  // Fetch book details when component mounts or when id changes
  useEffect(() => {
    console.log("UpdateBook component mounted with id:", id);
    
    if (id) {
      getBookById();
    } else {
      console.warn("No valid id found in URL parameters");
    }
  }, [id]);
  // Handle form submission to update book
const updateBook = async (event) => {
  event.preventDefault();
  try {
    const bookWithId = {
      Id: parseInt(id),
      title: book.title,
      author: book.author,
      price: parseFloat(book.price)
    };


    console.log("Sending data to API:", bookWithId);
    const response = await axios.put(
      `http://localhost:5139/api/books/${id}`,
      bookWithId
    );
    console.log("Updated book data:", response.data);
    alert("Book updated successfully!");
  } catch (error) {
    console.error("Error updating book:", error);
    alert("Error updating book: " + (error.response?.data || error.message));
  }
};


  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setBook((prevObj) => ({
      ...prevObj,
      [name]: name === 'price' ? (value === '' ? 0 : parseFloat(value)) : value
    }));
  };

  return (
    <div className="container">
      <h2 className="mb-3">Update Book</h2>
      <form onSubmit={updateBook} className="mb-3">
        <table className="table table-striped mb-3">
          <tbody>
            <tr>
              <td>Id</td>
              <td>
                <input
                  type="text"
                  name="Id"
                  value={book.Id}
                  onChange={(e) =>
                    setBook((prevObj) => ({
                      ...prevObj,
                      Id: e.target.value,
                    }))
                  }
                  className="form-control"
                />
              </td>
            </tr>
            <tr>
              <td>Title</td>
              <td>
                <input
                  type="text"
                  name="title"
                  value={book.title}
                  onChange={handleInputChange}
                  className="form-control"
                />
              </td>
            </tr>
            <tr>
              <td>Author</td>
              <td>
                <input
                  type="text"
                  name="author"
                  value={book.author}
                  onChange={handleInputChange}
                  className="form-control"
                />
              </td>
            </tr>
            <tr>
              <td>Price</td>
              <td>
                <input
                  type="number"
                  name="price"
                  value={book.price}
                  onChange={handleInputChange}
                  className="form-control"
                />
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit" className="btn btn-primary">Save Changes</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default UpdateBook;

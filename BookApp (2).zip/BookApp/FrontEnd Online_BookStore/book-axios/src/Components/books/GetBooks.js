import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
const GetBooks = () => {
  const [items, setItems] = useState([]);
  const [updateItem, setUpdateItem] = useState(null);
  const  navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:5139/api/books/Getbooks", {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token") || ""}`,
        },
      })
      .then((response) => {
        console.log(response.data);
        setItems(response.data);
      })
      .catch((error) => console.log(error));
  }, []);

  const handleUpdate = (id) => {
    setUpdateItem(id);
  };

  const Update = (id) => {
    if (!updateItem) return; // Prevent updating if no item selected

    const bookData = {
      title: prompt("Enter new title"),
      price: parseFloat(prompt("Enter new price")),
      author: prompt("Enter new author")
    };
    axios
      .post(`http://localhost:5139/api/books/Updatebook?id=${id}`, bookData)
      .then((res) => {
        console.log(res.data);
        // Refresh the book list after successful update
        axios.get("http://localhost:5139/api/books/Getbooks")
          .then((response) => {
            setItems(response.data);
            setUpdateItem(null);
          });
      })
      .catch((err) => {
        console.log(err.response.data);
        alert(`Failed to update book: ${err.response.data.error}`);
      });
  };

  const Remove = (BookId) => {
    axios
      .delete(`http://localhost:5139/api/books/Deletebook?id=${BookId}`)
      .then((res) => {
        console.log(res.data);
      })
      .catch((err) => console.log(err));
  };

  const updateBook=(bookId)=>{
    navigate(`/UpdateBooks/${bookId}`)
    }

  return (
    <div className="container mt-3">
      <div className="row">
        <div className="col-md-12">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Book List</h3>
            </div>
            <div className="card-body">
              <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                  <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Author</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {items.length > 0 ? (
                    items.map((item, index) => (
                      <tr key={item.id}>
                        <td>{index + 1}</td>
                        <td>{item.title}</td>
                        <td>{item.price.toFixed(2)}</td>
                        <td>{item.author}</td>
                        <td className="text-center">
                          <button onClick={() => updateBook(item.id)} className="btn btn-primary mr-2"> Update </button>
                          <button onClick={() => Remove(item.id)} className="btn btn-danger"> Delete </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="5">No books found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetBooks;

import React, { useState } from "react";
import axios from "axios";

const AddBook = () => {
  const [book, setBook] = useState({
    Title: "",
    Author: "",
    Price: 0,
  });
  const save = (event) => {
    event.preventDefault(); // Prevents form from refreshing the page
    console.log(book);
    axios
      .post("http://localhost:5139/api/books/AddBook", book)
      .then((res) => {
        
      const user = res.data;
        console.log(res.data);
        sessionStorage.setItem("bookId",user.id);
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="container">
      <form onSubmit={save} className="mb-3">
        <h2 className="mb-3">Add Book</h2>
        <table className="table table-striped mb-3">
          <thead>
            <tr>
              <th>Field</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Title</td>
              <td>
                <input
                  type="text"
                  value={book.Title}
                  onChange={(e) =>
                    setBook((prevObj) => ({
                      ...prevObj,
                      Title: e.target.value,
                    }))
                  }
                  className="form-control"
                />
              </td>
            </tr>
            <tr>
              <td>Author</td>
              <td>
                <input
                  type="text"
                  value={book.Author}
                  onChange={(e) =>
                    setBook((prevObj) => ({
                      ...prevObj,
                      Author: e.target.value,
                    }))
                  }
                  className="form-control"
                />
              </td>
            </tr>
            <tr>
            <td>Price</td>
            <td>
            <input
              type="number"
              value={book.price}
              onChange={(e) =>
              setBook((prevObj) => ({
               ...prevObj,
              price: parseFloat(e.target.value),
            }))
            }
            className="form-control"
         />
           </td>
           </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit" className="btn btn-primary">Save</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default AddBook;

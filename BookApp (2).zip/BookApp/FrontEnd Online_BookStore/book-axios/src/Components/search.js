import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom"; // Import this hook

const Search = () => {
  const [items, setItems] = useState([]);
  const [quantities, setQuantities] = useState({}); // State to track quantities for each book
  const navigate = useNavigate(); // Initialize the navigation hook

  useEffect(() => {
    axios
      .get("http://localhost:5139/api/books/Getbooks", {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log('this is response', response.data);
        setItems(response.data); // Update state with items
      })
      .catch((error) => console.log(error));
  }, []);

  const addToCart = (id, price, quantity) => {
    const totalPrice = price * quantity; // Calculate the total price

    const cart = {
      cartId: "0",
      bookId: id,
      price: price,
      Quantity: quantity,
      totalprice: totalPrice,
      userId: sessionStorage.getItem("userId"),
    };

    console.log(cart);

    axios
      .post("http://localhost:5139/api/CartItem/AddCartItem", cart)
      .then((response) => {
        console.log(response);
        navigate("/viewCart"); // Redirect to View Cart after adding item
      })
      .catch((error) => console.log(error));
  };

  // Handle quantity change for each book
  const handleQuantityChange = (id, quantity) => {
    setQuantities({ ...quantities, [id]: quantity });
  };

  return (
    <div className="container">
      <table className="table table-bordered table-hover">
        <thead className="table-primary">
          <tr>
            <td>Id</td>
            <td>Title</td>
            <td>Author</td>
            <td>Price</td>
            <td>Quantity</td> {/* Add quantity input */}
            <td>Action</td>
          </tr>
        </thead>
        <tbody>
          {items.map((i) => (
            <tr key={i.id}>
              <td>{i.id}</td>
              <td>{i.title}</td>
              <td>{i.author}</td>
              <td>{i.price}</td>
              <td>
                <input
                  type="number"
                  min="1"
                  value={quantities[i.id] || 1} // Default quantity is 1
                  onChange={(e) => handleQuantityChange(i.id, e.target.value)}
                />
              </td>
              <td>
                <button
                  onClick={() =>
                    addToCart(i.id, i.price, quantities[i.id] || 1)
                  }
                >
                  Add To Cart
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Search;

import React from "react";
import { useNavigate } from "react-router-dom";

const AdminDashboard = () => {
  // Retrieve the admin's name or userId from sessionStorage
  const adminName = sessionStorage.getItem("userId"); // Assuming userId is stored in sessionStorage
  const navigate = useNavigate();

  // Handle Logout
  const handleLogout = () => {
    sessionStorage.clear(); // Clear sessionStorage
    navigate("/login"); // Redirect to login page
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-8 col-lg-6">
          <div className="card shadow-sm border-0 rounded-lg">
            <div className="card-header bg-primary text-white text-center">
              <h2 className="card-title">Admin Dashboard</h2>
            </div>
            <div className="card-body text-center">
              <h3>Welcome to Admin Dashboard!</h3>
              {adminName && <p>Admin ID: {adminName}</p>}
              <p className="mt-4">
                You can manage the bookstore, add or update books, and view
                orders.
              </p>
              <div className="mt-3">
                {/* Link to Manage Books */}
                <a href="/GetBooks" className="btn btn-primary mx-2">
                  Manage Books
                </a>
                {/* Link to Add New Book */}
                <a href="/AddBook" className="btn btn-success mx-2">
                  Add New Book
                </a>
              </div>
              <div className="mt-4">
                {/* Logout Button */}
                <button onClick={handleLogout} className="btn btn-danger mx-2">
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;

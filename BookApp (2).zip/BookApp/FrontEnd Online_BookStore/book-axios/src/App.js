import React from "react";
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from "./Login";
import AdminDashboard from "./AdminDashbord";
import GetBooks from './Components/books/GetBooks';
import AddBook from './Components/books/AddBooks';
import UpdateBooks from './Components/books/UpdateBooks';
import UserDashboard from './UserDashbord';
import HomePage from "./Components/HomePage";
import Signup from "./Signup"
import Search from "./Components/search";
import ViewCart from "./Components/CartItem/ViewCart";

function App() {
  const userRole = sessionStorage.getItem("userRole");  // Get role from sessionStorage
  const isLoggedIn = !!sessionStorage.getItem("token"); // Check if user is logged in

  return (
    <div className="App">
      {/* Navigation Bar */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-purple fixed-top">
        <div className="container-fluid">
          <a className="navbar-brand" href="/">Bookstore</a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
              

              {!isLoggedIn ? (
                <>
                  <li className="nav-item">
                    <a className="nav-link" href="/Signup">Signup</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="/login">Login</a>
                  </li>
                </>
              ) : (
                <>
                  {userRole === "Admin" && (
                    <>
                      <li className="nav-item">
                        <a className="nav-link" href="/AdminDashboard/*">Admin Dashboard</a>
                      </li>
                      <li className="nav-item">
                        <a className="nav-link" href="/AddBook">Add Book</a>
                      </li>
                    </>
                  )}
                  {userRole === "User" && (
                    <>
                      <li className="nav-item">
                        <a className="nav-link" href="/UserDashboard/*">User Dashboard</a>
                      </li>
                      <li className="nav-item">
                        <a className="nav-link" href="/ViewCart">View Cart</a>
                      </li>
                      <li className="nav-item">
                        <a className="nav-link" href="/search">Search</a>
                      </li>
                    </>
                  )}
                </>
              )}
            </ul>
          </div>
        </div>
      </nav>

      {/* Router Setup */}
      <div className="container mt-5">
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/Signup" element={<Signup />} />
          

            {/* Admin Routes */}
            {isLoggedIn && userRole === "Admin" && (
              <>
                <Route path="/AdminDashboard/*" element={<AdminDashboard />} />
                <Route path="/AddBook" element={<AddBook />} />
                <Route path="/UpdateBooks/:id" element={<UpdateBooks />} />
              </>
            )}

            {/* User Routes */}
            {isLoggedIn && userRole === "User" && (
              <>
                <Route path="/UserDashboard/*" element={<UserDashboard />} />
                <Route path="/ViewCart" element={<ViewCart />} />
                <Route path="/search" element={<Search />} />
              </>
            )}

            {/* Redirect if unauthorized */}
            {!isLoggedIn && <Route path="*" element={<Navigate to="/login" />} />}
          </Routes>
        </BrowserRouter>
      </div>

      {/* Footer */}
      <footer className="footer bg-purple text-white py-3 fixed-bottom">
        <div className="container">
          <p className="mb-0">&copy; 2024 Online Bookstore</p>
          <a href="/privacy-policy" className="text-white text-decoration-none">Privacy Policy</a>
        </div>
      </footer>
    </div>
  );
}

export default App;

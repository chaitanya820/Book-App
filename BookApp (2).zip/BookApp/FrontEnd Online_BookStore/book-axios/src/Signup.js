import { useState } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom';

const Signup = () => {
    const [user, setUser] = useState({
        name: "",
        address: "",
        email: "",
        password: "",
        role: ""
    });

    const navigate = useNavigate(); 

    const save = (e) => {
        e.preventDefault();
        
        // Validate form fields
        if (!user.name || !user.address || !user.email || !user.password || !user.role) {
            alert("Please fill out all fields");
            return;
        }

        axios.post('http://localhost:5139/api/Auth/Register', user)
            .then((res) => {
                console.log(res.data);
                
                // Redirect to the login page after registration
                navigate('/login'); 
            })
            .catch((error) => {
                console.error("Registration failed:", error);
                alert("Registration failed. Please try again.");
            });
    };

    return (
        <div className="container mt-5">
            <h1 className="display-4 text-center mb-4">Signup</h1>
            <form onSubmit={save}>
                <table className="table table-bordered">
                    <tbody>
                        <tr>
                            <td className="col-form-label">Name</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    value={user.name}
                                    onChange={(e) =>
                                        setUser(prevObj => ({
                                            ...prevObj,
                                            name: e.target.value
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td className="col-form-label">Address</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    value={user.address}
                                    onChange={(e) =>
                                        setUser(prevObj => ({
                                            ...prevObj,
                                            address: e.target.value
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td className="col-form-label">Email</td>
                            <td>
                                <input 
                                    type="email" 
                                    className="form-control" 
                                    value={user.email}
                                    onChange={(e) =>
                                        setUser(prevObj => ({
                                            ...prevObj,
                                            email: e.target.value
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td className="col-form-label">Password</td>
                            <td>
                                <input 
                                    type="password" 
                                    className="form-control" 
                                    value={user.password}
                                    onChange={(e) =>
                                        setUser(prevObj => ({
                                            ...prevObj,
                                            password: e.target.value
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td className="col-form-label">Role</td>
                            <td>
                                <div className="custom-control custom-radio">
                                    <label className="custom-control-input">
                                        <input 
                                            type="radio" 
                                            id="adminRadio" 
                                            name="role" 
                                            value="Admin"
                                            checked={user.role === "Admin"}
                                            onChange={(e) =>
                                                setUser(prevObj => ({
                                                    ...prevObj,
                                                    role: e.target.value
                                                }))
                                            }
                                        />
                                        Admin
                                    </label>
                                </div>
                                <div className="custom-control custom-radio ml-3">
                                    <label className="custom-control-input">
                                        <input 
                                            type="radio" 
                                            id="userRadio" 
                                            name="role" 
                                            value="User"
                                            checked={user.role === "User"}
                                            onChange={(e) =>
                                                setUser(prevObj => ({
                                                    ...prevObj,
                                                    role: e.target.value
                                                }))
                                            }
                                        />
                                        User
                                    </label>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colSpan={3}>
                                <button type="submit" className="btn btn-primary w-100">Signup</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    );
};

export default Signup;

import React from "react";
import { useNavigate } from "react-router-dom";

const UserDashboard = () => {
  // Retrieve the user's name or ID from sessionStorage
  const userName = sessionStorage.getItem("userId"); // Assuming userId is stored in sessionStorage
  const navigate = useNavigate();

  // Handle Logout
  const handleLogout = () => {
    sessionStorage.clear(); // Clear sessionStorage
    navigate("/login"); // Redirect to login page
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-8 col-lg-6">
          <div className="card shadow-sm border-0 rounded-lg">
            <div className="card-header bg-primary text-white text-center">
              <h2 className="card-title">User Dashboard</h2>
            </div>
            <div className="card-body text-center">
              <h3>Welcome to User Dashboard!</h3>
              {userName && <p>User ID: {userName}</p>}
              <p className="mt-4">
                You can explore available books, view your cart, and search for books.
              </p>
              <div className="mt-3">
                {/* Link to Search Books */}
                <a href="/search" className="btn btn-primary mx-2">
                  Search Books
                </a>
                {/* Link to View Cart */}
                <a href="/ViewCart" className="btn btn-success mx-2">
                  View Cart
                </a>
              </div>
              <div className="mt-4">
                {/* Logout Button */}
                <button onClick={handleLogout} className="btn btn-danger mx-2">
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;

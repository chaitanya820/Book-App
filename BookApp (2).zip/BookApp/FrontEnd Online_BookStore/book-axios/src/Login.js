import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const user = { email, password };

      const response = await axios.post("http://localhost:5139/api/User/Validate", user);

      // Check if status is not 2xx or the response data is invalid
      if (response.status === 204 || !response.data || !response.data.role) {
        throw new Error("Invalid User Credentials");
      }

      const userData = response.data;

      // Save user data in session storage
      sessionStorage.setItem("token", userData.token);
      sessionStorage.setItem("userId", userData.userId);
      sessionStorage.setItem("address", userData.address);
      sessionStorage.setItem("userRole", userData.role);

      // Navigate based on the user's role
      if (userData.role === "Admin") {
        navigate("/AdminDashboard");
      } else if (userData.role === "User") {
        navigate("/UserDashboard");
      } else {
        throw new Error("Unknown User Role");
      }
    } catch (error) {
      console.error("Login error:", error);
      setError(error.message || "An error occurred during login");
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-8 col-lg-6">
          <div className="card shadow-sm border-0 rounded-lg">
            <div className="card-header bg-primary text-white">
              <h3 className="card-title mb-0">Login</h3>
            </div>
            <div className="card-body">
              <form onSubmit={handleLogin} className="mb-5">
                <div className="mb-3">
                  <label htmlFor="emailInput" className="form-label">Email Address</label>
                  <input
                    type="email"
                    className="form-control"
                    id="emailInput"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter Email Address..."
                    required
                  />
                </div>
                
                <div className="mb-3">
                  <label htmlFor="passwordInput" className="form-label">Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="passwordInput"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    required
                  />
                </div>

                <button type="submit" className="btn btn-primary w-100 py-2 mt-4">Login</button>

                {error && (
                  <div className="alert alert-danger mt-3" role="alert">
                    {error}
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
